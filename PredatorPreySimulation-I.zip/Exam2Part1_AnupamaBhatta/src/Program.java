
/**
 * Name: Anupama Bhatta
 * Date: 03/12/2019
 * Description: Method that runs the program.
 */

public class Program {
    public static void main(String[] args) {
        new UI_Grid().setVisible(true);
    }
}
