package MainPackage;

/**
 * Name: Anupama Bhatta
 * Date: 03/20/2019
 * Description: A Java application with a simple 2D predator-prey simulation.
 */

public class Program {
        public static void main(String[] args)
	{
	    UI_Grid gridForm = new UI_Grid();
            gridForm.setVisible(true);
	}    
} 

    
    

